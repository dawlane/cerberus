//
//  helloframework.h
//  helloframework
//

#import <Foundation/Foundation.h>

//! Project version number for helloframework.
FOUNDATION_EXPORT double helloframeworkVersionNumber;

//! Project version string for helloframework.
FOUNDATION_EXPORT const unsigned char helloframeworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <helloframework/PublicHeader.h>

FOUNDATION_EXPORT char* Msg(const char *name);
FOUNDATION_EXPORT void MemFree();


