All licence files should go into a unique named directory for each library used.
