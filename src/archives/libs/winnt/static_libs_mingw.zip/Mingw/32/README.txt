Place 32 bit MinGW static libraries here.
