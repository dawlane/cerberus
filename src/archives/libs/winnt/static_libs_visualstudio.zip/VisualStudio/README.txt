As it is possible for the ABI of a library to change between different versions of Visual Studio.

Each version should be placed in the directory named under the version it was built with.

When a version becomes old, any libraries that still work with a later vserion of VS
should by moved into that versions static directory.



The common directory is where any third-party sources that get compiled for the current compiler tool chain should be stored.