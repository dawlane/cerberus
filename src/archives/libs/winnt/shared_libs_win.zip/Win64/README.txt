Place all shared 64 bit libraries (.dll) for Windows in this directory. Any licences for them need to be placed in the libs\licences.
See the README in the libs directory for details on how they should be formated.
